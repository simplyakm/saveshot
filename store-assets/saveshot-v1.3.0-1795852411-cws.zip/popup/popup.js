import { isCapturableUrl } from '../lib/capture.js';
import { formatVersionTooltip, getEnvironmentSummary } from '../lib/feedback.js';
import { normalizeSettingsObject } from '../lib/storage.js';
import {
  applyDocumentTheme,
  didAuthProfileVisiblyChange,
  formatShortcutDisplay,
  initThemeSync,
  normalizeTheme,
  safeHttpsUrl,
  sendRuntimeMessage,
} from '../lib/ui.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

const els = {
  helpBtn: document.getElementById('help-btn'),
  openDriveBtn: document.getElementById('open-drive-btn'),
  settingsToggleBtn: document.getElementById('settings-toggle-btn'),
  signOutBtn: document.getElementById('sign-out-btn'),
  loadingView: document.getElementById('loading-view'),
  signedOutView: document.getElementById('signed-out-view'),
  setupBanner: document.getElementById('setup-banner'),
  signInBtn: document.getElementById('sign-in-btn'),
  authError: document.getElementById('auth-error'),
  mainView: document.getElementById('main-view'),
  accountFolderCard: document.getElementById('account-folder-card'),
  userAvatar: document.getElementById('user-avatar'),
  userEmail: document.getElementById('user-email'),
  folderChip: document.getElementById('folder-chip'),
  folderChipName: document.getElementById('folder-chip-name'),
  settingsDrawer: document.getElementById('settings-drawer'),
  driveFolderField: document.getElementById('drive-folder-field'),
  driveOptionsGroup: document.getElementById('drive-options-group'),
  folderNameInput: document.getElementById('folder-name-input'),
  saveFolderBtn: document.getElementById('save-folder-btn'),
  themeSegmented: document.getElementById('theme-segmented'),
  autoCopySegmented: document.getElementById('auto-copy-segmented'),
  editBeforeUploadCheckbox: document.getElementById('edit-before-upload-checkbox'),
  incognitoNotice: document.getElementById('incognito-notice'),
  restrictedWarning: document.getElementById('restricted-warning'),
  captureRegionBtn: document.getElementById('capture-region-btn'),
  captureVisibleBtn: document.getElementById('capture-visible-btn'),
  captureFullpageBtn: document.getElementById('capture-fullpage-btn'),
  shortcutRegion: document.getElementById('popup-shortcut-region'),
  shortcutVisible: document.getElementById('popup-shortcut-visible'),
  statusBanner: document.getElementById('status-banner'),
  recentSection: document.getElementById('recent-section'),
  clearHistoryBtn: document.getElementById('clear-history-btn'),
  emptyHistory: document.getElementById('empty-history'),
  uploadList: document.getElementById('upload-list'),
  popupVersion: document.getElementById('popup-version'),
  footerBugBtn: document.getElementById('footer-bug-btn'),
};

let authActionInFlight = false;

let currentState = {
  signedIn: false,
  activeTabId: undefined,
  incognito: false,
  lastErrorCode: '',
  settings: null,
  capturable: {
    ok: true,
    canCaptureVisible: true,
    canCaptureRegion: true,
    reason: null,
    regionDisabledReason: null,
  },
  busy: false,
};

function createActionSvg(kind) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('width', '14');
  svg.setAttribute('height', '14');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', kind === 'check' ? '2.3' : '1.95');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');

  const add = (tag, attrs) => {
    const el = document.createElementNS(SVG_NS, tag);
    for (const [k, v] of Object.entries(attrs)) {
      el.setAttribute(k, v);
    }
    svg.appendChild(el);
  };

  if (kind === 'edit') {
    add('path', { d: 'M12 20h9' });
    add('path', { d: 'M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z' });
  } else if (kind === 'copy') {
    add('rect', { x: '9', y: '9', width: '13', height: '13', rx: '2' });
    add('path', { d: 'M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1' });
  } else if (kind === 'open') {
    add('path', { d: 'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6' });
    add('polyline', { points: '15 3 21 3 21 9' });
    add('line', { x1: '10', y1: '14', x2: '21', y2: '3' });
  } else if (kind === 'check') {
    add('polyline', { points: '20 6 9 17 4 12' });
  }
  return svg;
}

function openHelpPage({ kind = '', errorCode = '', jumpToFeedback = false } = {}) {
  const params = new URLSearchParams();
  if (kind) params.set('kind', kind);
  if (errorCode) params.set('error', errorCode);
  const qs = params.toString() ? `?${params.toString()}` : '';
  const hash = jumpToFeedback ? '#feedback' : '';
  chrome.tabs.create({ url: chrome.runtime.getURL(`pages/welcome.html${qs}${hash}`) });
}

async function getPopupActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab || null;
  } catch {
    return null;
  }
}

function formatRelativeTime(isoString) {
  if (!isoString) return '';
  const ts = Date.parse(isoString);
  if (Number.isNaN(ts)) return '';
  const diffSec = Math.max(0, Math.floor((Date.now() - ts) / 1000));
  if (diffSec < 45) return 'Just now';
  if (diffSec < 3600) return `${Math.floor(diffSec / 60)}m ago`;
  if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
  return `${Math.floor(diffSec / 86400)}d ago`;
}

function renderThemeButtons(theme) {
  const active = normalizeTheme(theme);
  applyDocumentTheme(active);
  for (const btn of els.themeSegmented.querySelectorAll('[data-theme-opt]')) {
    const isActive = btn.dataset.themeOpt === active;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-pressed', String(isActive));
  }
}

function showStatus(type, content) {
  els.statusBanner.hidden = false;
  els.statusBanner.className = `status-banner ${type}`;
  els.statusBanner.replaceChildren();

  if (type === 'loading') {
    const spinner = document.createElement('div');
    spinner.className = 'ss-spinner';
    const text = document.createElement('span');
    text.textContent = content;
    els.statusBanner.append(spinner, text);
    return;
  }

  if (type === 'error') {
    const details = typeof content === 'string' ? { message: content } : content || {};
    if (details.code) currentState.lastErrorCode = details.code;

    const msg = document.createElement('div');
    msg.textContent = details.message || 'Could not upload screenshot.';
    els.statusBanner.append(msg);

    const actions = document.createElement('div');
    actions.className = 'status-actions';

    if (details.hasFallback) {
      const saveLocalBtn = document.createElement('button');
      saveLocalBtn.type = 'button';
      saveLocalBtn.className = 'ss-btn ss-btn-sm ss-btn-primary';
      saveLocalBtn.textContent = 'Save PNG locally';
      saveLocalBtn.addEventListener('click', async () => {
        saveLocalBtn.disabled = true;
        try {
          const fallback = await sendRuntimeMessage({ type: 'GET_FALLBACK_PNG' });
          if (fallback.ok && fallback.dataUrl) {
            const a = document.createElement('a');
            a.href = fallback.dataUrl;
            a.download = fallback.filename || details.fallbackFilename || 'Screenshot.png';
            a.click();
            saveLocalBtn.textContent = 'Saved!';
          } else {
            saveLocalBtn.textContent = 'Expired';
          }
        } catch {
          saveLocalBtn.textContent = 'Failed';
        }
      });
      actions.append(saveLocalBtn);
    }

    if (details.code === 'DRIVE_QUOTA_EXCEEDED') {
      const manageQuota = document.createElement('a');
      manageQuota.className = 'ss-btn ss-btn-sm ss-btn-secondary';
      manageQuota.href = 'https://drive.google.com/drive/quota';
      manageQuota.target = '_blank';
      manageQuota.rel = 'noopener noreferrer';
      manageQuota.textContent = 'Manage storage';
      actions.append(manageQuota);
    }

    if (details.requiresReauth) {
      const reconnectBtn = document.createElement('button');
      reconnectBtn.type = 'button';
      reconnectBtn.className = 'ss-btn ss-btn-sm ss-btn-secondary';
      reconnectBtn.textContent = 'Reconnect';
      reconnectBtn.addEventListener('click', async () => {
        reconnectBtn.disabled = true;
        try {
          const res = await sendRuntimeMessage({ type: 'SIGN_IN' });
          if (res.ok) {
            await loadState();
          } else if (res.error) {
            msg.textContent = res.error;
          }
        } finally {
          reconnectBtn.disabled = false;
        }
      });
      actions.append(reconnectBtn);
    }

    const reportBtn = document.createElement('button');
    reportBtn.type = 'button';
    reportBtn.className = 'ss-btn ss-btn-sm ss-btn-secondary';
    reportBtn.textContent = 'Report bug';
    reportBtn.addEventListener('click', () => {
      openHelpPage({
        kind: 'bug',
        errorCode: details.code || currentState.lastErrorCode,
        jumpToFeedback: true,
      });
    });
    actions.append(reportBtn);

    els.statusBanner.append(actions);
    return;
  }

  if (type === 'success' && typeof content === 'object') {
    const label = document.createElement('span');
    label.textContent = content.message;
    els.statusBanner.append(label);

    const safeLink = safeHttpsUrl(content.webViewLink);
    if (content.fileId || safeLink) {
      const inlineActions = document.createElement('div');
      inlineActions.className = 'status-inline-actions';

      if (content.fileId) {
        const editBtn = document.createElement('button');
        editBtn.type = 'button';
        editBtn.className = 'status-link-action';
        editBtn.textContent = 'Edit';
        editBtn.title = 'Annotate, redact, rotate, or rename screenshot';
        editBtn.addEventListener('click', () => {
          openEditorForUpload({
            fileId: content.fileId,
            filename: content.filename || 'Screenshot.png',
            webViewLink: safeLink,
            folderName: content.folderName || currentState.settings?.folderName,
          });
        });
        inlineActions.append(editBtn);
      }

      if (safeLink) {
        const openLink = document.createElement('a');
        openLink.className = 'status-link-action';
        openLink.href = safeLink;
        openLink.target = '_blank';
        openLink.rel = 'noopener noreferrer';
        openLink.textContent = 'Open';
        inlineActions.append(openLink);
      }

      els.statusBanner.append(inlineActions);
    }
  }
}

async function openEditorForUpload({ fileId, filename, webViewLink, folderName }) {
  if (!fileId) return;
  try {
    const res = await sendRuntimeMessage({
      type: 'OPEN_EDITOR',
      fileId,
      filename,
      webViewLink,
      folderName,
    });
    if (res.ok) {
      window.close();
      return;
    }
    showStatus('error', {
      message: res.error || 'Could not open screenshot editor.',
      code: res.code,
      requiresReauth: res.requiresReauth,
    });
  } catch (err) {
    showStatus('error', err.message || 'Could not open screenshot editor.');
  }
}

function hideStatus() {
  els.statusBanner.hidden = true;
}

function setAvatarInitial(initial) {
  const span = document.createElement('span');
  span.className = 'avatar-initial';
  span.textContent = initial;
  els.userAvatar.replaceChildren(span);
}

let lastRenderedProfileKey = '';
let lastRenderedUploadsKey = '';

function renderProfile(profile) {
  const name = profile?.name || 'Google Account';
  const email = profile?.email || '';
  const safePic = safeHttpsUrl(profile?.picture);
  const profileKey = `${email}\0${name}\0${safePic}`;
  if (profileKey === lastRenderedProfileKey) return;
  lastRenderedProfileKey = profileKey;

  els.userEmail.textContent = email || name;
  els.userEmail.title = email && name && name !== email ? `${name} (${email})` : email || name;

  const initial = (email || name || 'G').trim().charAt(0).toUpperCase();

  if (safePic) {
    const img = document.createElement('img');
    img.src = safePic;
    img.alt = name;
    img.width = 18;
    img.height = 18;
    img.decoding = 'async';
    img.referrerPolicy = 'no-referrer';
    img.addEventListener('error', () => setAvatarInitial(initial));
    els.userAvatar.replaceChildren(img);
  } else {
    setAvatarInitial(initial);
  }
}

function renderAutoCopyButtons(mode) {
  const active = mode === 'link' || mode === 'off' ? mode : 'image';
  for (const btn of els.autoCopySegmented.querySelectorAll('[data-copy-opt]')) {
    const isActive = btn.dataset.copyOpt === active;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-pressed', String(isActive));
    if (btn.dataset.copyOpt === 'link') {
      btn.disabled = !currentState.signedIn;
      btn.title = currentState.signedIn
        ? 'Copy Google Drive link after upload'
        : 'Connect Google Drive to auto-copy Drive links';
    }
  }
}

function renderSettings(settings) {
  currentState.settings = settings;
  const folderName = settings?.folderName || 'Chrome_SaveShot_ScreenShots';
  els.folderChipName.textContent = folderName;
  els.folderChip.href = safeHttpsUrl(
    settings?.folderWebViewLink,
    'https://drive.google.com/drive/my-drive'
  );
  els.folderNameInput.value = folderName;
  renderAutoCopyButtons(settings?.autoCopyMode);
  els.editBeforeUploadCheckbox.checked = Boolean(settings?.editBeforeUpload);
  renderThemeButtons(settings?.theme);
}

function renderRecentUploads(uploads) {
  const list = Array.isArray(uploads) ? uploads : [];
  const uploadsKey = list
    .map(
      (item) =>
        `${item.id || ''}|${item.name || ''}|${item.pageTitle || ''}|${item.mode || ''}|${item.createdTime || ''}|${item.webViewLink || ''}|${(item.thumbnailDataUrl || '').length}`
    )
    .join('\n');
  if (uploadsKey === lastRenderedUploadsKey && els.uploadList.hidden === (list.length === 0)) {
    return;
  }
  lastRenderedUploadsKey = uploadsKey;

  if (list.length === 0) {
    els.uploadList.replaceChildren();
    els.emptyHistory.hidden = false;
    els.uploadList.hidden = true;
    els.clearHistoryBtn.hidden = true;
    return;
  }

  els.emptyHistory.hidden = true;
  els.uploadList.hidden = false;
  els.clearHistoryBtn.hidden = false;

  const frag = document.createDocumentFragment();

  for (const item of list) {
    const li = document.createElement('li');
    li.className = 'upload-item';

    if (
      typeof item.thumbnailDataUrl === 'string' &&
      item.thumbnailDataUrl.startsWith('data:image/')
    ) {
      const thumb = document.createElement('img');
      thumb.className = 'upload-thumb';
      thumb.src = item.thumbnailDataUrl;
      thumb.alt = item.name || 'Screenshot';
      thumb.width = 42;
      thumb.height = 30;
      thumb.decoding = 'async';
      li.append(thumb);
    } else {
      const placeholder = document.createElement('div');
      placeholder.className = 'upload-thumb-placeholder';
      placeholder.textContent = 'PNG';
      li.append(placeholder);
    }

    const meta = document.createElement('div');
    meta.className = 'upload-meta';

    const title = document.createElement('div');
    title.className = 'ss-body upload-name';
    title.textContent = item.pageTitle || item.name || 'Screenshot';
    title.title = item.name || '';

    const sub = document.createElement('div');
    sub.className = 'ss-meta tabular';
    const modeWord =
      item.mode === 'region' ? 'Area' : item.mode === 'fullpage' ? 'Full page' : 'Tab';
    const relTime = formatRelativeTime(item.createdTime);
    sub.textContent = relTime ? `${modeWord} \u00b7 ${relTime}` : modeWord;

    meta.append(title, sub);

    const actions = document.createElement('div');
    actions.className = 'upload-actions';

    const safeLink = safeHttpsUrl(item.webViewLink);

    if (item.id) {
      const editBtn = document.createElement('button');
      editBtn.type = 'button';
      editBtn.className = 'ss-icon-btn';
      editBtn.title = 'Edit screenshot';
      editBtn.setAttribute('aria-label', 'Edit screenshot');
      editBtn.append(createActionSvg('edit'));
      editBtn.addEventListener('click', () => {
        openEditorForUpload({
          fileId: item.id,
          filename: item.name || 'Screenshot.png',
          webViewLink: safeLink,
          folderName: currentState.settings?.folderName,
        });
      });
      actions.append(editBtn);
    }

    if (safeLink) {
      const copyBtn = document.createElement('button');
      copyBtn.type = 'button';
      copyBtn.className = 'ss-icon-btn';
      copyBtn.title = 'Copy Drive link';
      copyBtn.setAttribute('aria-label', 'Copy Drive link');
      copyBtn.append(createActionSvg('copy'));
      let copyTimer = null;
      copyBtn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(safeLink);
          if (copyTimer) clearTimeout(copyTimer);
          copyBtn.classList.add('copied');
          copyBtn.replaceChildren(createActionSvg('check'));
          copyTimer = setTimeout(() => {
            copyTimer = null;
            copyBtn.classList.remove('copied');
            copyBtn.replaceChildren(createActionSvg('copy'));
          }, 1400);
        } catch {
          copyBtn.title = 'Could not copy link';
        }
      });

      const openLink = document.createElement('a');
      openLink.className = 'ss-icon-btn';
      openLink.href = safeLink;
      openLink.target = '_blank';
      openLink.rel = 'noopener noreferrer';
      openLink.title = 'Open in Google Drive';
      openLink.setAttribute('aria-label', 'Open in Google Drive');
      openLink.append(createActionSvg('open'));

      actions.append(copyBtn, openLink);
    }

    li.append(meta, actions);
    frag.append(li);
  }

  els.uploadList.replaceChildren(frag);
}

function updateCaptureAvailability() {
  const cap = currentState.capturable || {};
  const canVisible = Boolean(cap.canCaptureVisible ?? cap.ok);
  const canRegion = Boolean(cap.canCaptureRegion ?? cap.ok);

  els.captureVisibleBtn.disabled = currentState.busy || !canVisible;
  els.captureRegionBtn.disabled = currentState.busy || !canRegion;
  els.captureFullpageBtn.disabled = currentState.busy || !canRegion;

  els.incognitoNotice.hidden = !(currentState.signedIn && currentState.incognito);

  const warningMsg = !canVisible
    ? cap.reason
    : !canRegion
    ? cap.regionDisabledReason
    : null;

  if (warningMsg) {
    els.restrictedWarning.textContent = warningMsg;
    els.restrictedWarning.hidden = false;
  } else {
    els.restrictedWarning.hidden = true;
  }
}

function showView(viewName, { signedIn = false, needsSetup = false } = {}) {
  if (viewName === 'loading') {
    els.loadingView.hidden = false;
    els.mainView.hidden = true;
    els.openDriveBtn.hidden = true;
    els.settingsToggleBtn.hidden = true;
    els.signOutBtn.hidden = true;
    return;
  }

  els.loadingView.hidden = true;
  els.mainView.hidden = false;
  els.settingsToggleBtn.hidden = false;
  els.openDriveBtn.hidden = !signedIn;
  els.signOutBtn.hidden = !signedIn;
  els.signedOutView.hidden = signedIn;
  els.accountFolderCard.hidden = !signedIn;
  els.recentSection.hidden = !signedIn;
  els.driveFolderField.hidden = !signedIn;
  els.driveOptionsGroup.hidden = !signedIn;
  els.setupBanner.hidden = signedIn || !needsSetup;
  renderAutoCopyButtons(currentState.settings?.autoCopyMode);
}

function initStaticMetadata() {
  const env = getEnvironmentSummary();
  els.popupVersion.textContent = `v${env.extensionVersion}`;
  els.popupVersion.title = formatVersionTooltip(env);

  if (chrome?.commands?.getAll) {
    chrome.commands.getAll((commands) => {
      let sawRegion = false;
      let sawVisible = false;
      for (const cmd of commands || []) {
        if (cmd.name === 'capture-region') {
          sawRegion = true;
          els.shortcutRegion.textContent = cmd.shortcut
            ? formatShortcutDisplay(cmd.shortcut)
            : 'Shortcut not set';
        } else if (cmd.name === 'capture-visible') {
          sawVisible = true;
          els.shortcutVisible.textContent = cmd.shortcut
            ? formatShortcutDisplay(cmd.shortcut)
            : 'Shortcut not set';
        }
      }
      if (!sawRegion) els.shortcutRegion.textContent = 'Shortcut not set';
      if (!sawVisible) els.shortcutVisible.textContent = 'Shortcut not set';
    });
  }
}

let stateLoadSeq = 0;
let stateLoadInFlight = false;
let pendingRecentUploads = null;
let userMutatedSettings = false;
let statusOwnedByAction = false;

function isFileSchemeAllowedPopup() {
  if (typeof chrome?.extension?.isAllowedFileSchemeAccess !== 'function') {
    return Promise.resolve(false);
  }
  return new Promise((resolve) => {
    chrome.extension.isAllowedFileSchemeAccess((allowed) => {
      void chrome.runtime?.lastError;
      resolve(Boolean(allowed));
    });
  });
}

async function hydratePopupFromLocalCache(cachedData, activeTab) {
  if (!cachedData || typeof cachedData !== 'object') return false;
  const settings = normalizeSettingsObject(cachedData.settings);
  renderSettings(settings);

  const tabUrl = typeof activeTab?.url === 'string' ? activeTab.url : '';
  currentState.activeTabId = typeof activeTab?.id === 'number' ? activeTab.id : undefined;
  currentState.incognito = Boolean(activeTab?.incognito);
  if (tabUrl) {
    const allowFileScheme = tabUrl.startsWith('file:')
      ? await isFileSchemeAllowedPopup()
      : true;
    currentState.capturable = isCapturableUrl(tabUrl, { allowFileScheme });
  } else if (typeof activeTab?.id === 'number') {
    // Restricted pages (chrome://, Chrome Web Store) omit tab.url under activeTab
    currentState.capturable = isCapturableUrl('');
  } else {
    currentState.capturable = { ok: true, canCaptureVisible: true, canCaptureRegion: true };
  }

  const hasProfile = Boolean(cachedData.userProfile?.email || cachedData.userProfile?.name);
  const signedIn = !Boolean(cachedData.signedOut) && hasProfile;
  currentState.signedIn = signedIn;

  if (signedIn) {
    renderProfile(cachedData.userProfile);
    renderRecentUploads(Array.isArray(cachedData.recentUploads) ? cachedData.recentUploads : []);
  } else {
    renderRecentUploads([]);
  }
  updateCaptureAvailability();
  showView('main', { signedIn, needsSetup: false });
  return true;
}

async function loadState({ showSpinner = true, useLocalCache = false } = {}) {
  const seq = ++stateLoadSeq;
  stateLoadInFlight = true;
  pendingRecentUploads = null;
  if (!useLocalCache) {
    userMutatedSettings = false;
    statusOwnedByAction = false;
  }
  if (showSpinner) {
    showView('loading');
  }
  try {
    let activeTab = null;
    if (useLocalCache && chrome?.storage?.local?.get) {
      const [cachedData, queriedTab] = await Promise.all([
        chrome.storage.local
          .get(['settings', 'recentUploads', 'signedOut', 'userProfile'])
          .catch(() => null),
        getPopupActiveTab(),
      ]);
      if (seq !== stateLoadSeq || authActionInFlight) return;
      activeTab = queriedTab;
      await hydratePopupFromLocalCache(cachedData, activeTab);
      if (seq !== stateLoadSeq || authActionInFlight) return;
    } else {
      activeTab = await getPopupActiveTab();
      if (seq !== stateLoadSeq || authActionInFlight) return;
    }

    currentState.activeTabId = typeof activeTab?.id === 'number' ? activeTab.id : undefined;
    const res = await sendRuntimeMessage({
      type: 'GET_STATE',
      tabId: currentState.activeTabId,
      tabUrl: typeof activeTab?.url === 'string' ? activeTab.url : '',
      tabIncognito: Boolean(activeTab?.incognito),
    });
    if (seq !== stateLoadSeq || authActionInFlight) return;
    if (!res.ok) throw new Error(res.error);

    currentState.capturable = res.capturable || {
      ok: true,
      canCaptureVisible: true,
      canCaptureRegion: true,
    };
    currentState.incognito = Boolean(res.incognito);
    currentState.lastErrorCode = res.lastErrorCode || '';

    if (res.settings && !userMutatedSettings) {
      renderSettings(res.settings);
    }

    if (!res.session?.signedIn) {
      currentState.signedIn = false;
      pendingRecentUploads = null;
      renderRecentUploads([]);
      if (!statusOwnedByAction) {
        els.authError.hidden = true;
      }
      updateCaptureAvailability();
      if (!currentState.busy && !statusOwnedByAction) hideStatus();
      showView('main', {
        signedIn: false,
        needsSetup: Boolean(res.session?.needsSetup),
      });
      return;
    }

    currentState.signedIn = true;
    const recentToRender = pendingRecentUploads !== null ? pendingRecentUploads : res.recentUploads;
    pendingRecentUploads = null;
    renderProfile(res.session.profile);
    renderRecentUploads(recentToRender);
    updateCaptureAvailability();
    if (!currentState.busy && !statusOwnedByAction) hideStatus();
    showView('main', { signedIn: true, needsSetup: false });
  } catch (err) {
    if (seq !== stateLoadSeq || authActionInFlight) return;
    currentState.signedIn = false;
    pendingRecentUploads = null;
    els.authError.textContent = err.message || 'Could not load SaveShot.';
    els.authError.className = 'ss-alert error';
    els.authError.hidden = false;
    updateCaptureAvailability();
    showView('main', { signedIn: false, needsSetup: false });
  } finally {
    if (seq === stateLoadSeq) {
      stateLoadInFlight = false;
    }
  }
}

els.helpBtn.addEventListener('click', () => openHelpPage());
els.footerBugBtn.addEventListener('click', () =>
  openHelpPage({
    kind: 'bug',
    errorCode: currentState.lastErrorCode,
    jumpToFeedback: true,
  })
);

els.signInBtn.addEventListener('click', async () => {
  els.signInBtn.disabled = true;
  els.authError.hidden = true;
  stateLoadSeq += 1;
  statusOwnedByAction = true;
  authActionInFlight = true;
  try {
    const res = await sendRuntimeMessage({ type: 'SIGN_IN' });
    if (!res.ok) {
      const err = new Error(res.error || 'Google sign-in failed.');
      err.code = res.code;
      throw err;
    }
    authActionInFlight = false;
    await loadState({ showSpinner: false });
  } catch (err) {
    els.authError.textContent = err.message || 'Google sign-in failed.';
    els.authError.className =
      err.code === 'AUTH_CANCELLED' ? 'ss-alert warning' : 'ss-alert error';
    els.authError.hidden = false;
  } finally {
    authActionInFlight = false;
    els.signInBtn.disabled = false;
  }
});

els.signOutBtn.addEventListener('click', async () => {
  els.signOutBtn.disabled = true;
  stateLoadSeq += 1;
  statusOwnedByAction = false;
  userMutatedSettings = false;
  authActionInFlight = true;
  try {
    await sendRuntimeMessage({ type: 'SIGN_OUT' });
    currentState.signedIn = false;
    els.settingsDrawer.hidden = true;
    els.settingsToggleBtn.classList.remove('active');
    els.settingsToggleBtn.setAttribute('aria-expanded', 'false');
    renderRecentUploads([]);
    els.authError.hidden = true;
    hideStatus();
    updateCaptureAvailability();
    showView('main', { signedIn: false, needsSetup: false });
  } finally {
    authActionInFlight = false;
    els.signOutBtn.disabled = false;
  }
});

els.settingsToggleBtn.addEventListener('click', () => {
  const willShow = els.settingsDrawer.hidden;
  els.settingsDrawer.hidden = !willShow;
  els.settingsToggleBtn.classList.toggle('active', willShow);
  els.settingsToggleBtn.setAttribute('aria-expanded', String(willShow));
});

els.saveFolderBtn.addEventListener('click', async () => {
  const folderName = els.folderNameInput.value.trim() || 'Chrome_SaveShot_ScreenShots';
  els.saveFolderBtn.disabled = true;
  userMutatedSettings = true;
  statusOwnedByAction = true;
  try {
    const res = await sendRuntimeMessage({
      type: 'UPDATE_SETTINGS',
      patch: { folderName },
    });
    if (res.ok) {
      renderSettings(res.settings);
      showStatus('success', {
        message: `Saving new screenshots to "${res.settings.folderName}"`,
      });
    }
  } finally {
    els.saveFolderBtn.disabled = false;
  }
});

for (const btn of els.themeSegmented.querySelectorAll('[data-theme-opt]')) {
  btn.addEventListener('click', async () => {
    const theme = normalizeTheme(btn.dataset.themeOpt);
    userMutatedSettings = true;
    renderThemeButtons(theme);
    const res = await sendRuntimeMessage({
      type: 'UPDATE_SETTINGS',
      patch: { theme },
    });
    if (res.ok) renderSettings(res.settings);
  });
}

for (const btn of els.autoCopySegmented.querySelectorAll('[data-copy-opt]')) {
  btn.addEventListener('click', async () => {
    if (btn.disabled) return;
    const autoCopyMode = btn.dataset.copyOpt;
    userMutatedSettings = true;
    renderAutoCopyButtons(autoCopyMode);
    const res = await sendRuntimeMessage({
      type: 'UPDATE_SETTINGS',
      patch: { autoCopyMode },
    });
    if (res.ok) renderSettings(res.settings);
  });
}

els.editBeforeUploadCheckbox.addEventListener('change', async () => {
  userMutatedSettings = true;
  const res = await sendRuntimeMessage({
    type: 'UPDATE_SETTINGS',
    patch: { editBeforeUpload: els.editBeforeUploadCheckbox.checked },
  });
  if (res.ok) renderSettings(res.settings);
});

els.captureVisibleBtn.addEventListener('click', async () => {
  if (currentState.busy) return;
  currentState.busy = true;
  statusOwnedByAction = true;
  updateCaptureAvailability();
  showStatus('loading', 'Opening screenshot editor...');

  try {
    const res = await sendRuntimeMessage({
      type: 'CAPTURE_VISIBLE',
      tabId: currentState.activeTabId,
    });
    if (!res.ok) {
      showStatus('error', {
        message: res.error,
        code: res.code,
        requiresReauth: res.requiresReauth,
        hasFallback: res.hasFallback,
        fallbackFilename: res.fallbackFilename,
      });
      return;
    }

    if (res.openedEditor) {
      window.close();
      return;
    }
  } catch (err) {
    showStatus('error', err.message || 'Could not capture screenshot.');
  } finally {
    currentState.busy = false;
    updateCaptureAvailability();
  }
});

els.captureFullpageBtn.addEventListener('click', async () => {
  if (currentState.busy) return;
  currentState.busy = true;
  statusOwnedByAction = true;
  updateCaptureAvailability();
  showStatus('loading', 'Starting full-page capture...');

  try {
    const res = await sendRuntimeMessage({
      type: 'CAPTURE_FULLPAGE',
      tabId: currentState.activeTabId,
      background: true,
    });
    if (!res.ok) {
      showStatus('error', {
        message: res.error || 'Could not capture full page.',
        code: res.code,
        requiresReauth: res.requiresReauth,
      });
      return;
    }

    if (res.started || res.openedEditor) {
      window.close();
      return;
    }
  } catch (err) {
    showStatus('error', err.message || 'Could not capture full page.');
  } finally {
    currentState.busy = false;
    updateCaptureAvailability();
  }
});

els.captureRegionBtn.addEventListener('click', async () => {
  if (currentState.busy) return;
  currentState.busy = true;
  statusOwnedByAction = true;
  updateCaptureAvailability();

  try {
    const res = await sendRuntimeMessage({
      type: 'START_REGION_CAPTURE',
      tabId: currentState.activeTabId,
    });
    if (!res.ok) {
      currentState.busy = false;
      updateCaptureAvailability();
      showStatus('error', {
        message: res.error || 'Could not start region selection.',
        code: res.code,
        requiresReauth: res.requiresReauth,
      });
      return;
    }
    window.close();
  } catch (err) {
    currentState.busy = false;
    updateCaptureAvailability();
    showStatus('error', err.message || 'Could not start region selection.');
  }
});

els.folderNameInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    els.saveFolderBtn.click();
  }
});

let openingFolder = false;

async function openDestinationDriveFolder() {
  if (openingFolder) return;
  const cached = safeHttpsUrl(currentState.settings?.folderWebViewLink);
  if (cached.includes('/drive/folders/')) {
    chrome.tabs.create({ url: cached });
    return;
  }
  openingFolder = true;
  try {
    const res = await sendRuntimeMessage({ type: 'OPEN_DRIVE_FOLDER' });
    const url = safeHttpsUrl(res.ok ? res.url : '', 'https://drive.google.com/drive/my-drive');
    if (currentState.settings && url.includes('/drive/folders/')) {
      currentState.settings.folderWebViewLink = url;
      els.folderChip.href = url;
    }
    chrome.tabs.create({ url });
  } catch {
    chrome.tabs.create({ url: 'https://drive.google.com/drive/my-drive' });
  } finally {
    openingFolder = false;
  }
}

els.openDriveBtn.addEventListener('click', () => {
  openDestinationDriveFolder();
});

els.folderChip.addEventListener('click', (event) => {
  const currentHref = els.folderChip.href || '';
  if (currentHref.includes('/drive/folders/')) return;
  event.preventDefault();
  openDestinationDriveFolder();
});

els.clearHistoryBtn.addEventListener('click', async () => {
  const res = await sendRuntimeMessage({ type: 'CLEAR_HISTORY' });
  if (res.ok) renderRecentUploads([]);
});

if (chrome?.storage?.onChanged?.addListener) {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local' || authActionInFlight) return;
    if (didAuthProfileVisiblyChange(changes)) {
      loadState({ showSpinner: false });
      if (changes.recentUploads) {
        pendingRecentUploads = changes.recentUploads.newValue || [];
      }
      return;
    }
    if (changes.settings?.newValue) {
      renderSettings(changes.settings.newValue);
    }
    if (changes.recentUploads) {
      const nextUploads = changes.recentUploads.newValue || [];
      if (stateLoadInFlight) {
        pendingRecentUploads = nextUploads;
      }
      if (currentState.signedIn) {
        renderRecentUploads(nextUploads);
      }
    }
  });
}

initThemeSync(null, { skipInitialRead: true });
initStaticMetadata();
loadState({ showSpinner: false, useLocalCache: true });
